package com.example.bojan.googlelocatinapi;

import android.Manifest;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Location;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.util.Collections;

import static com.google.android.gms.common.GoogleApiAvailability.*;

public class MainActivity extends AppCompatActivity {

    //variables for UI
    TextView latitudeTxtView;
    TextView longitudeTxtView;
    TextView providerTxtView;
    TextView timeTxtView;
    TextView accuracyTextView;
    TextView bearingTextView;
    TextView speedTextView;
    TextView altitudeTextView;



    private static final int REQUEST_CHECK_SETTINGS = 1;//todo sluzi da obradi odgovor za dobijanje od korisnika

    private static final int MY_PERMISIN_REQUEST_ACCESS_FINE_LOCATION = 2;

    FusedLocationProviderClient fusedLocationProviderClient;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        latitudeTxtView = findViewById(R.id.latitude_id);
        longitudeTxtView = findViewById(R.id.longitude_id);
        providerTxtView = findViewById(R.id.privider_id);
        timeTxtView = findViewById(R.id.time_ID);
        accuracyTextView = findViewById(R.id.accuracy_id);
        bearingTextView = findViewById(R.id.bearing_id);
        speedTextView = findViewById(R.id.speed_id);
        altitudeTextView = findViewById(R.id.altitude_id);

        //todo I postavljanje lokacijskog zahteva klasom Location Request
        LocationRequest locationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)// podesavanje prioriteta isporuke podataka
                .setInterval(5000)//podesavanje intervala isporuke podataka, vreme na 5sec za isporuku podata
                .setFastestInterval(1000);//podesavanje najkraceg intervala za isporuku podataka

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addAllLocationRequests(Collections.singleton(locationRequest));
        SettingsClient client = LocationServices.getSettingsClient(this);

        //todo Task se koristi za predstavljanje asihronih poslova... cesto se koristi u generickoj verziji sa tipom povratne vrednosti...
        // todo sto znaci da vraca povratnu vrednost LocationSettingsResponse
        Task<LocationSettingsResponse> task = client.checkLocationSettings(builder.build());
        //todo za dobijanje informacija o uspesnom izvrsavanju task operacije
        task.addOnSuccessListener(this, new OnSuccessListener<LocationSettingsResponse>() {
            @Override
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                    //todo kod za proveru postojanaj doyvole ACCESS_FINE_LOCATION
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){

                    getLastKnownLocation();
                }else {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISIN_REQUEST_ACCESS_FINE_LOCATION);
                }

            }
        });
        //todo za dobijanje informacija o ne uspesnom izvrsavanju task operacije
        task.addOnFailureListener(this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

              if (e instanceof ResolvableApiException){
                  try {
                      ResolvableApiException resolvableApiException = (ResolvableApiException) e;
                      resolvableApiException.startResolutionForResult(MainActivity.this, REQUEST_CHECK_SETTINGS);
                  } catch (IntentSender.SendIntentException e1) {
                      //ignore error
                  }
              }
        }
        });

        //todo dobijanje podataka poslednje poznate lokacije
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);


    }

    //todo metoda za dobijanje poslednje poynate lokacije
    private void getLastKnownLocation() throws SecurityException{
        fusedLocationProviderClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null){
                    //display data
                    displayLocationData(location);


                }else{
                    Toast.makeText(MainActivity.this,"There is no last know location", Toast.LENGTH_LONG).show();
                }
            }
        });
    }


    //todo metoda za prikaz podataka
    private void displayLocationData(Location location){
        double lat = location.getLatitude();
        double lng = location.getLongitude();
        String provider = location.getProvider();
        long time = location.getTime();
        float accuracy = location.getAccuracy();
        float bearing = location.getBearing();
        float speed = location.getSpeed();
        double altitude = location.getAltitude();

        latitudeTxtView.setText(String.valueOf(lat));
        longitudeTxtView.setText(String.valueOf(lng));
        providerTxtView.setText(provider);

        timeTxtView.setText(String.valueOf(time));
        accuracyTextView.setText(String.valueOf(accuracy));

        bearingTextView.setText(String.valueOf(bearing));
        speedTextView.setText(String.valueOf(speed));
        altitudeTextView.setText(String.valueOf(altitude));

    }

    //todo Obrada odgovora korinika na zahtev
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch (requestCode){
            case REQUEST_CHECK_SETTINGS:
                if (resultCode == RESULT_OK){
                    //todo kod za proveru postojanaj doyvole ACCESS_FINE_LOCATION
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){

                        getLastKnownLocation();
                    }else {
                        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISIN_REQUEST_ACCESS_FINE_LOCATION);
                    }
                }else {
                    Toast.makeText(this, "Location is turned off by user", Toast.LENGTH_LONG).show();
                }
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISIN_REQUEST_ACCESS_FINE_LOCATION: {
                if (grantResults.length >0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    getLastKnownLocation();
                }else{
                    Toast.makeText(this, "App doesn't have permission for accessing location", Toast.LENGTH_LONG).show();
                }
                break;
            }
        }
    }
}
