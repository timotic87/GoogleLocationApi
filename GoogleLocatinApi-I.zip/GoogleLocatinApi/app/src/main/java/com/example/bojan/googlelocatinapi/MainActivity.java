package com.example.bojan.googlelocatinapi;

import android.content.Intent;
import android.content.IntentSender;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.util.Collections;

import static com.google.android.gms.common.GoogleApiAvailability.*;

public class MainActivity extends AppCompatActivity {

//todo kreiranje lokacijskog zahteva i provera korisnickih podesavanja

    private static final int REQUEST_CHECK_SETTINGS = 1;//todo sluzi da obradi odgovor za dobijanje od korisnika


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //todo I postavljanje lokacijskog zahteva klasom Location Request
        LocationRequest locationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)// podesavanje prioriteta isporuke podataka
                .setInterval(5000)//podesavanje intervala isporuke podataka, vreme na 5sec za isporuku podata
                .setFastestInterval(1000);//podesavanje najkraceg intervala za isporuku podataka

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addAllLocationRequests(Collections.singleton(locationRequest));
        SettingsClient client = LocationServices.getSettingsClient(this);

        //todo Task se koristi za predstavljanje asihronih poslova... cesto se koristi u generickoj verziji sa tipom povratne vrednosti...
        // todo sto znaci da vraca povratnu vrednost LocationSettingsResponse
        Task<LocationSettingsResponse> task = client.checkLocationSettings(builder.build());
        //todo za dobijanje informacija o uspesnom izvrsavanju task operacije
        task.addOnSuccessListener(this, new OnSuccessListener<LocationSettingsResponse>() {
            @Override
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                Toast.makeText(MainActivity.this, "Enabled", Toast.LENGTH_LONG).show();
            }
        });
        //todo za dobijanje informacija o ne uspesnom izvrsavanju task operacije
        task.addOnFailureListener(this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

              if (e instanceof ResolvableApiException){
                  try {
                      ResolvableApiException resolvableApiException = (ResolvableApiException) e;
                      resolvableApiException.startResolutionForResult(MainActivity.this, REQUEST_CHECK_SETTINGS);
                  } catch (IntentSender.SendIntentException e1) {
                      //ignore error
                  }
              }
        }
        });


    }
    //todo Obrada odgovor korinika na zahtev
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch (requestCode){
            case REQUEST_CHECK_SETTINGS:
                if (resultCode == RESULT_OK){
                    Toast.makeText(this, "User enabled location", Toast.LENGTH_LONG).show();
                }else {
                    Toast.makeText(this, "Location is turned off by user", Toast.LENGTH_LONG).show();
                }
                break;
        }
    }
}
